import chalk from 'chalk'

// ===========================
// COMANDOS RESTRINGIDOS EN SUB-BOTS SIN PREMIUM
// ===========================
export const restrictedCommands = [
  // Descargas pesadas
  'play', 'play2', 'mp3', 'mp4', 'ytmp3', 'ytmp4',
  'spotify', 'sp', 'spoti',
  'tiktok', 'tt',
  'facebook', 'fb',
  'instagram', 'ig', 'reel',
  'twitter', 'x',
  'mediafire', 'mf',
  'pinterest', 'pin',
  'pinterestimg', 'pinimg',
  'pinvid', 'pinvideo',
  'wallpaper', 'wall',
  // Gacha
  'rollwaifu', 'rw', 'roll',
  'claim', 'c', 'reclamar',
  'harem', 'waifus',
  'trade', 'sell', 'buychar',
  // Otros
  'spamwa', 'spam',
  'animeinfo', 'animeinf',
  'stickerdow', 'sdow',
]

// ===========================
// PRECIOS DE PREMIUM (en coins)
// ===========================
export const premiumPlans = {
  '1h':  { label: '1 Hora',    duration: 1000 * 60 * 60,          price: 500   },
  '1d':  { label: '1 Día',     duration: 1000 * 60 * 60 * 24,     price: 2000  },
  '7d':  { label: '7 Días',    duration: 1000 * 60 * 60 * 24 * 7, price: 10000 },
}

export default {
  command: ['comprarpremium', 'premium', 'buypremium'],
  category: 'economy',

  run: async (client, m, args, usedPrefix, command) => {
    const botId = client.user.id.split(':')[0] + '@s.whatsapp.net'
    const settings = global.db.data.settings?.[botId] || {}
    const user = global.db.data.users?.[m.sender] || {}
    const banner = global.getBocchiBanner?.() || 'https://files.catbox.moe/k2r00m.jpg'

    const plan = args[0]?.toLowerCase()

    // ===========================
    // SIN ARGUMENTOS - MOSTRAR PLANES
    // ===========================
    if (!plan) {
      const premiumData = user.premium
      const ahora = Date.now()
      const tienePremium = premiumData?.expiry && premiumData.expiry > ahora
      const tiempoRestante = tienePremium ? formatTime(premiumData.expiry - ahora) : null

      const caption = `┏━━━━━✦❘༻👑༺❘✦━━━━━┓
┃ —͟͞ ♱ *SISTEMA PREMIUM* ♱ —͟͞
┗━━━━━✦❘༻👑༺❘✦━━━━━┛

${tienePremium ? `╭─━━━⊱ *TU ESTADO* ⊰━━━─╮
│
│ 👑 *Premium:* ACTIVO ✅
│ ⏰ *Expira en:* ${tiempoRestante}
│
╰─━━━⊱✧༻♱༺✧⊰━━━─╯\n` : `╭─━━━⊱ *TU ESTADO* ⊰━━━─╮
│
│ 👑 *Premium:* Inactivo ❌
│ 💰 *Coins:* ${(user.coins || 0).toLocaleString()}
│
╰─━━━⊱✧༻♱༺✧⊰━━━─╯\n`}
╭─━━━⊱ *PLANES DISPONIBLES* ⊰━━━─╮
│
│ |🜸 *1h* → ${premiumPlans['1h'].price.toLocaleString()} coins
│    └─ ${premiumPlans['1h'].label} de acceso total
│
│ |🜸 *1d* → ${premiumPlans['1d'].price.toLocaleString()} coins
│    └─ ${premiumPlans['1d'].label} de acceso total
│
│ |🜸 *7d* → ${premiumPlans['7d'].price.toLocaleString()} coins
│    └─ ${premiumPlans['7d'].label} de acceso total
│
╰─━━━⊱✧༻♱༺✧⊰━━━─╯

╭─━━━⊱ *COMANDOS DESBLOQUEADOS* ⊰━━━─╮
│
│ |🜸 play, spotify, tiktok
│ |🜸 pinterest, wallpaper
│ |🜸 rollwaifu, claim, harem
│ |🜸 stickerdow, animeinfo
│ |🜸 Y muchos más...
│
╰─━━━⊱✧༻♱༺✧⊰━━━─╯

▰▰▰▰▰
—͟͞ ♱ *Uso:* ${usedPrefix}premium [plan]
—͟͞ ♱ *Ejemplo:* ${usedPrefix}premium 1d
▰▰▰▰▰

> ❄️ *Kurumi Protocol* - NanoVoid 💜`

      await client.sendMessage(m.chat, {
        image: { url: banner },
        caption,
        contextInfo: {
          externalAdReply: {
            title: '👑 Sistema Premium',
            body: 'Desbloquea todos los comandos',
            mediaType: 1,
            thumbnailUrl: banner,
            renderLargerThumbnail: false
          }
        }
      }, { quoted: m })
      return
    }

    // ===========================
    // COMPRAR PLAN
    // ===========================
    const selectedPlan = premiumPlans[plan]

    if (!selectedPlan) {
      return m.reply(`❌ Plan inválido.\n\nPlanes disponibles:\n|🜸 *1h* - ${premiumPlans['1h'].price} coins\n|🜸 *1d* - ${premiumPlans['1d'].price} coins\n|🜸 *7d* - ${premiumPlans['7d'].price} coins`)
    }

    const userCoins = user.coins || 0

    // Verificar coins suficientes
    if (userCoins < selectedPlan.price) {
      const falta = selectedPlan.price - userCoins
      return m.reply(`╭─━━━⊱ *COINS INSUFICIENTES* ⊰━━━─╮
│
│ |🜸 *Necesitas:* ${selectedPlan.price.toLocaleString()} coins
│ |🜸 *Tienes:* ${userCoins.toLocaleString()} coins
│ |🜸 *Faltan:* ${falta.toLocaleString()} coins
│
╰─━━━⊱✧༻♱༺✧⊰━━━─╯

|🜸 Usa *${usedPrefix}work*, *${usedPrefix}daily* para ganar más coins.`)
    }

    // Verificar si ya tiene premium activo
    const ahora = Date.now()
    const premiumData = user.premium
    const yaActivo = premiumData?.expiry && premiumData.expiry > ahora

    // Calcular nueva expiración
    const baseTime = yaActivo ? premiumData.expiry : ahora
    const nuevaExpiry = baseTime + selectedPlan.duration

    // Descontar coins
    global.db.data.users[m.sender].coins = userCoins - selectedPlan.price

    // Guardar premium
    global.db.data.users[m.sender].premium = {
      active: true,
      plan,
      expiry: nuevaExpiry,
      boughtAt: ahora
    }

    console.log(chalk.green(`[PREMIUM] ✓ ${m.sender} compró plan ${plan} hasta ${new Date(nuevaExpiry).toLocaleString()}`))

    const caption = `┏━━━━━✦❘༻👑༺❘✦━━━━━┓
┃ —͟͞ ♱ *¡PREMIUM ACTIVADO!* ♱ —͟͞
┗━━━━━✦❘༻👑༺❘✦━━━━━┛

╭─━━━⊱ *RESUMEN* ⊰━━━─╮
│
│ 👑 *Plan:* ${selectedPlan.label}
│ 💰 *Costo:* ${selectedPlan.price.toLocaleString()} coins
│ ⏰ *Expira:* ${new Date(nuevaExpiry).toLocaleString('es-ES')}
│ 💳 *Coins restantes:* ${(userCoins - selectedPlan.price).toLocaleString()}
│
╰─━━━⊱✧༻♱༺✧⊰━━━─╯

|🜸 Ahora tienes acceso a *TODOS* los comandos.
${yaActivo ? '|🜸 Tu premium anterior fue *extendido*.' : ''}

> ❄️ *Kurumi Protocol* - NanoVoid 💜`

    await client.sendMessage(m.chat, {
      image: { url: banner },
      caption,
      mentions: [m.sender]
    }, { quoted: m })

    await m.react('👑')
  }
}

// ===========================
// HELPERS
// ===========================
export function formatTime(ms) {
  const d = Math.floor(ms / 86400000)
  const h = Math.floor((ms % 86400000) / 3600000)
  const m = Math.floor((ms % 3600000) / 60000)
  const s = Math.floor((ms % 60000) / 1000)
  if (d > 0) return `${d}d ${h}h ${m}m`
  if (h > 0) return `${h}h ${m}m ${s}s`
  return `${m}m ${s}s`
}

export function hasPremium(sender) {
  const user = global.db.data.users?.[sender]
  if (!user?.premium) return false
  if (user.premium.expiry < Date.now()) {
    // Limpiar premium expirado
    user.premium.active = false
    return false
  }
  return true
}

