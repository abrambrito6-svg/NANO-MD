import { Browsers, makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, makeCacheableSignalKeyStore, DisconnectReason, jidDecode, } from '@whiskeysockets/baileys';
import qrcode from "qrcode"
import NodeCache from 'node-cache';
import main from '../main.js'
import events from '../cmds/events.js'
import pino from 'pino';
import fs from 'fs';
import chalk from 'chalk';
import { smsg } from './message.js';
import moment from 'moment-timezone';

if (!global.conns) global.conns = []
const msgRetryCounterCache = new NodeCache({ stdTTL: 0, checkperiod: 0, useClones: false })
const userDevicesCache = new NodeCache({ stdTTL: 300, checkperiod: 60, useClones: false })
const groupCache = new NodeCache({ stdTTL: 7200, checkperiod: 600, useClones: false })
let reintentos = {}
const cleanJid = (jid = '') => jid.replace(/:\d+/, '').split('@')[0]

export async function startSubBot(m, client, caption = '', isCode = false, phone = '', chatId = '', commandFlags = {}, isCommand = false) {
  const id = phone || (m?.sender || '').split('@')[0]
  const sessionFolder = `./Sessions/Subs/${id}`
  const senderId = m?.sender

  const { state, saveCreds } = await useMultiFileAuthState(sessionFolder)
  const { version } = await fetchLatestBaileysVersion()

console.info = () => {} 
const sock = makeWASocket({
  logger: pino({ level: 'silent' }),
  printQRInTerminal: false,
  browser: Browsers.macOS('Chrome'),
  auth: state,
  markOnlineOnConnect: false,
  generateHighQualityLinkPreview: false,
  syncFullHistory: false,
  getMessage: async () => '',
  msgRetryCounterCache,
  userDevicesCache,
  cachedGroupMetadata: async (jid) => groupCache.get(jid),
  version,
  keepAliveIntervalMs: 60_000,
  maxIdleTimeMs: 120_000,
  })
  sock.isInit = false
  sock.ev.on('creds.update', saveCreds)

  sock.decodeJid = (jid) => {
    if (!jid) return jid
    if (/:\d+@/gi.test(jid)) {
      let decode = jidDecode(jid) || {}
      return (decode.user && decode.server && decode.user + '@' + decode.server) || jid
    } else return jid
  }

  sock.ev.on('connection.update', async ({ connection, lastDisconnect, isNewLogin, qr }) => {
    if (isNewLogin) sock.isInit = false
    if (connection === 'open') {
      sock.uptime = Date.now();
      sock.isInit = true
      sock.userId = cleanJid(sock.user?.id?.split('@')[0])
      const botDir = sock.userId + '@s.whatsapp.net'
      if (!global.db.data.settings[botDir]) {
        global.db.data.settings[botDir] = {}
      }
      global.db.data.settings[botDir].type = 'Sub'
      if (!global.conns.find((c) => c.userId === sock.userId)) {
        global.conns.push(sock)
      }

      delete reintentos[sock.userId || id]
      await joinChannels(sock)
     console.log(chalk.green(`[root@kurumi]# ./connect_subbot.sh ${chalk.yellow(sock.userId)} [OK]`))
    
    }

    if (connection === 'close') {
      const botId = sock.userId || id
      const reason = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.reason || 0
      const intentos = reintentos[botId] || 0
      reintentos[botId] = intentos + 1
      if ([401, 403].includes(reason)) {
        if (intentos < 5) {
          console.log(chalk.gray(`[ ✿  ]  SUB-BOT ${botId} Conexión cerrada (código ${reason}) intento ${intentos}/5 → Reintentando...`))
          setTimeout(() => {
            startSubBot(m, client, caption, isCode, phone, chatId, {}, isCommand)
          }, 3000)
        } else {
          console.log(chalk.gray(`[ ✿  ]  SUB-BOT ${botId} Falló tras 5 intentos. Eliminando sesión.`))
          try {
            fs.rmSync(sessionFolder, { recursive: true, force: true })
          } catch (e) {
            console.error(`[ ✿  ] No se pudo eliminar la carpeta ${sessionFolder}:`, e)
          }
          delete reintentos[botId]
        }
        return
      }

      if ([DisconnectReason.connectionClosed, DisconnectReason.connectionLost, DisconnectReason.timedOut, DisconnectReason.connectionReplaced].includes(reason)) {
        setTimeout(() => {
          startSubBot(m, client, caption, isCode, phone, chatId, {}, isCommand)
        }, 3000)
        return
      }
      setTimeout(() => {
        startSubBot(m, client, caption, isCode, phone, chatId, {}, isCommand)
      }, 3000)
    }
    
    if (qr && isCode && phone && client && chatId && commandFlags[senderId]) {
    try {
    let codeGen = await sock.requestPairingCode(phone, 'KURUMI12');
    codeGen = codeGen.match(/.{1,4}/g)?.join("-") || codeGen;
const botJid2 = client.user?.id?.split(':')[0] + '@s.whatsapp.net'
const botCfg = global.db.data?.settings?.[botJid2] || {}
const imgUrl = 'https://files.catbox.moe/lwepuq.jpg'
const msg = await client.sendMessage(chatId, { image: { url: imgUrl }, caption }, { quoted: m })    

const msgCode = await m.reply(codeGen);
    delete commandFlags[senderId];
    setTimeout(async () => {
    try {
    await client.sendMessage(chatId, { delete: msg.key });
    await client.sendMessage(chatId, { delete: msgCode.key });
    } catch {}
    }, 60000);
    } catch (err) {
    console.error("[Código Error]", err);
    }}
    if (qr && !isCode && client && chatId && commandFlags[senderId]) {
    try {
    const msgQR = await client.sendMessage(m.chat, { image: await qrcode.toBuffer(qr, { scale: 8 }), caption }, { quoted: m})
    delete commandFlags[senderId]
    setTimeout(async () => {
    try {
    await client.sendMessage(chatId, { delete: msgQR.key })
    } catch {}
    }, 60000)
    } catch (err) {
    console.error("[QR Error]", err)
    }}
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return
    for (let raw of messages) {
      if (!raw.message) continue
      let msg = await smsg(sock, raw)
      try {
        main(sock, msg, messages)
      } catch (err) {
        console.log(chalk.gray(`[ ✿  ]  Sub » ${err}`))
      }
    }
  })
 
  try {
  await events(sock, m)
  } catch (err) {
   console.log(chalk.gray(`[ BOT  ]  → ${err}`))
  }
if (!global.subsErrorHandler) { global.subsErrorHandler = true 
  process.on('uncaughtException', console.error)
}
   return sock
}

async function joinChannels(client) {
for (const value of Object.values(global.my)) {
if (typeof value === 'string' && value.endsWith('@newsletter')) {
await client.newsletterFollow(value).catch(err => console.log(chalk.gray(`\n[ ✿ ] Error al seguir el canal ${value}`)))
}}}
